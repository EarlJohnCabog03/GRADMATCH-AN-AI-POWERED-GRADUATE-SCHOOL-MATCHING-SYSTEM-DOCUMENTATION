## Goal
Turn GradMatch AI into a real signed-in product with persisted data across four new feature areas, in addition to the existing Dashboard / AI Chat / Profile / Research pages.

## 1. Auth + Cloud Sync (foundation)
- Enable Lovable Cloud.
- Email/password + Google sign-in on a new `/auth` page (sign-in + sign-up tabs).
- Protected app subtree under `_authenticated/` — Dashboard, AI Chat, Profile, Applications, Deadlines, SOPs, Programs all require sign-in. Research stays public.
- `profiles` table (1:1 with `auth.users`, auto-created by trigger) — migrates the existing Profile form (personal info, academic background, test scores, goals, preferences) to the cloud.
- Top-right nav gets a user menu (avatar initials → Sign out).

## 2. Application Tracker + Deadlines
- New `/applications` route with a board/table of schools the user is applying to.
- Per-application fields: school, program, degree, deadline, status (Researching / Drafting / Submitted / Interview / Accepted / Rejected / Waitlisted), priority (Reach/Target/Safety), fee, notes, link.
- Add / edit / delete via a dialog form (zod-validated).
- Status grouping with counts, plus filter by status/priority.
- New `/deadlines` route with a calendar + upcoming list view (next 30/60/90 days), pulled from application deadlines + custom deadline rows (e.g. GRE date, recommender due).
- "Add to calendar" .ics export per deadline.

## 3. SOP Workspace
- New `/sop` route listing SOP documents (one per program or general).
- Editor view per document: title, target school/program, body (long-form textarea), word count, last saved.
- Version history: every "Save as version" snapshots the body; can view & restore prior versions.
- "Get AI feedback" button → Lovable AI Gateway server function returns structured critique (clarity, specificity, fit, grammar, suggestions).

## 4. Program Explorer
- New `/programs` route with search + filters (degree, field, country, GRE-required, funding).
- Seeded list of ~40-60 sample programs (static JSON in repo for v1 — no scraping). Cards show school, program, deadline, fit-score (derived from profile).
- "Add to my applications" button creates a row in the tracker.
- Detail dialog with full program info + faculty interest tags.

## Nav / Header
Header tabs become: Dashboard · Applications · Deadlines · SOPs · Programs · AI Chat · Profile · Research. (Mobile: same items in the hamburger / bottom nav.)

## Technical notes
- Stack: TanStack Start + Lovable Cloud (Supabase under the hood). Server functions via `createServerFn`; AI calls via Lovable AI Gateway (`google/gemini-3-flash-preview`).
- Tables: `profiles`, `applications`, `deadlines`, `sop_documents`, `sop_versions`. RLS scoped to `auth.uid()` on every table; explicit GRANTs to `authenticated`.
- Programs list is static JSON for v1 (no DB table) — keeps scope tight; can be moved to DB later.
- TanStack Query for all reads; `useMutation` + key invalidation for writes.
- Existing Profile page rewired to read/write the cloud `profiles` row instead of local state.

## Out of scope for this pass
- Letters of recommendation tracker (can add next).
- Real scraped program database, payments, email reminders, push notifications, Play Store packaging.

## Build order
1. Enable Cloud + auth + protected layout + migrate Profile.
2. Applications + Deadlines (shared schema concept).
3. SOP workspace + AI feedback.
4. Program explorer + "add to applications" wiring.
